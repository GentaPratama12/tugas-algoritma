/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int a, b;
    
    cout << "masukan bilangan ganjil: ";
    cin >> a;
    
    cout << "masukan bilangan genap: ";
    cin >> b;
    
    if(a % 2!= 0 && b % 2 ==0){
      cout << endl << "benar, ini bilangan ganjil dan genap"<< endl;  
    }else {
        cout << "dia bukan bilangan ganjil dan genap" << endl;
    }

    return 0;
}

